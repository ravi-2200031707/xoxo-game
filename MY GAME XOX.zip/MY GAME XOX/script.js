document.addEventListener("DOMContentLoaded", function() {
  const board = document.getElementById('board');
  const resetButton = document.getElementById('reset-btn');
  const modal = document.getElementById('modal');
  const closeButton = document.querySelector('.close');
  const newGameButton = document.getElementById('new-game-btn');
  const resultText = document.getElementById('result');
  let currentPlayer = 'X';
  let cells = [];

  // Create the grid
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.index = i;
    cell.addEventListener('click', handleCellClick);
    board.appendChild(cell);
    cells.push(cell);
  }

  // Handle cell click
  function handleCellClick() {
    if (!this.textContent) {
      this.textContent = currentPlayer;
      if (checkWinner()) {
        showModal(`${currentPlayer} wins!`);
      } else if (checkDraw()) {
        showModal('It\'s a draw!');
      } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
      }
    }
  }

  // Check for a winner
  function checkWinner() {
    const winningCombos = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];

    return winningCombos.some(combo => {
      return combo.every(index => {
        return cells[index].textContent === currentPlayer;
      });
    });
  }

  // Check for a draw
  function checkDraw() {
    return cells.every(cell => {
      return cell.textContent !== '';
    });
  }

  // Reset the board
  function resetBoard() {
    cells.forEach(cell => {
      cell.textContent = '';
    });
    currentPlayer = 'X';
  }

  // Show modal
  function showModal(message) {
    resultText.textContent = message;
    modal.style.display = 'block';
  }

  // Close modal
  function closeModal() {
    modal.style.display = 'none';
  }

  // Reset board and close modal
  function resetBoardAndCloseModal() {
    resetBoard();
    closeModal();
  }

  // Event listeners
  resetButton.addEventListener('click', resetBoard);
  closeButton.addEventListener('click', closeModal);
  newGameButton.addEventListener('click', resetBoardAndCloseModal);
});
